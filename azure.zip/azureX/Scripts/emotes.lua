-- Emote Hub Script for Executors

local player = game.Players.LocalPlayer
local humanoid = player.Character and player.Character:FindFirstChildOfClass("Humanoid") or nil

if not humanoid then
    player.CharacterAdded:Wait()
    humanoid = player.Character:WaitForChild("Humanoid")
end

-- Replace these IDs with the emote IDs you want to use
local emoteIds = {
    "rbxassetid://507771019", -- Balloon Float (replace with actual ID)
    "rbxassetid://507771020", -- Jerk Off (replace with actual ID)
    -- Add more emotes as needed
}

local function playEmote(emoteId)
    local animation = Instance.new("Animation")
    animation.AnimationId = emoteId
    humanoid:LoadAnimation(animation):Play()
end

-- Create the GUI
local screenGui = Instance.new("ScreenGui")
local frame = Instance.new("Frame")
local titleLabel = Instance.new("TextLabel")
local exitButton = Instance.new("TextButton")

screenGui.Parent = game.CoreGui
frame.Size = UDim2.new(0.3, 0, 0.4, 0)
frame.Position = UDim2.new(0.35, 0, 0.3, 0)
frame.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
frame.Parent = screenGui

titleLabel.Size = UDim2.new(1, 0, 0.2, 0)
titleLabel.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
titleLabel.Text = "Emote Hub"
titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
titleLabel.Font = Enum.Font.FredokaOne
titleLabel.TextSize = 24
titleLabel.Parent = frame

-- Create Buttons for Each Emote
for i, emoteId in ipairs(emoteIds) do
    local emoteButton = Instance.new("TextButton")
    emoteButton.Size = UDim2.new(0.8, 0, 0.2, 0)
    emoteButton.Position = UDim2.new(0.1, 0, 0.2 + (0.25 * (i - 1)), 0)
    emoteButton.BackgroundColor3 = Color3.fromRGB(100, 100, 100)
    emoteButton.Text = "Play Emote " .. i
    emoteButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    emoteButton.Parent = frame

    emoteButton.MouseButton1Click:Connect(function()
        playEmote(emoteId)
    end)
end

-- Exit Button
exitButton.Size = UDim2.new(0.3, 0, 0.2, 0)
exitButton.Position = UDim2.new(0.35, 0, 0.85, 0)
exitButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
exitButton.Text = "Close"
exitButton.TextColor3 = Color3.fromRGB(255, 255, 255)
exitButton.Parent = frame

exitButton.MouseButton1Click:Connect(function()
    screenGui:Destroy() -- Closes the Emote Hub
end)
