-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local PlayerTextBox = Instance.new("TextBox")
local PlayButton = Instance.new("TextButton")
local Exit = Instance.new("TextButton")
local StopRape = Instance.new("TextButton")
local TextLabel_2 = Instance.new("TextLabel")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.ResetOnSpawn = false

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
Frame.BorderColor3 = Color3.fromRGB(0, 0, 0)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.302209228, 0, 0.344198167, 0)
Frame.Size = UDim2.new(0, 270, 0, 179)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
TextLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0, 0, -0.00591829885, 0)
TextLabel.Size = UDim2.new(0, 270, 0, 40)
TextLabel.Font = Enum.Font.FredokaOne
TextLabel.Text = "Epic Sex Script"
TextLabel.TextColor3 = Color3.fromRGB(255, 0, 0)
TextLabel.TextSize = 28.000
TextLabel.TextWrapped = true

PlayerTextBox.Name = "PlayerTextBox"
PlayerTextBox.Parent = Frame
PlayerTextBox.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
PlayerTextBox.BorderColor3 = Color3.fromRGB(0, 0, 0)
PlayerTextBox.BorderSizePixel = 0
PlayerTextBox.Position = UDim2.new(0.113605186, 0, 0.257162601, 0)
PlayerTextBox.Size = UDim2.new(0, 208, 0, 38)
PlayerTextBox.Font = Enum.Font.SourceSansBold
PlayerTextBox.PlaceholderColor3 = Color3.fromRGB(189, 0, 0)
PlayerTextBox.PlaceholderText = "Victims Name Here"
PlayerTextBox.Text = ""
PlayerTextBox.TextColor3 = Color3.fromRGB(255, 0, 0)
PlayerTextBox.TextSize = 21.000
PlayerTextBox.TextWrapped = true

PlayButton.Name = "PlayButton"
PlayButton.Parent = Frame
PlayButton.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
PlayButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
PlayButton.BorderSizePixel = 0
PlayButton.Position = UDim2.new(0, 32, 0, 93)
PlayButton.Size = UDim2.new(0, 207, 0, 25)
PlayButton.Font = Enum.Font.SourceSansBold
PlayButton.Text = "RAPE THEM"
PlayButton.TextColor3 = Color3.fromRGB(255, 0, 0)
PlayButton.TextSize = 14.000

Exit.Name = "Exit"
Exit.Parent = Frame
Exit.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
Exit.BorderColor3 = Color3.fromRGB(255, 255, 255)
Exit.BorderSizePixel = 0
Exit.Position = UDim2.new(0, 239, 0, 7)
Exit.Size = UDim2.new(0, 25, 0, 24)
Exit.Font = Enum.Font.SourceSansBold
Exit.Text = "X"
Exit.TextColor3 = Color3.fromRGB(255, 0, 0)
Exit.TextScaled = true
Exit.TextSize = 14.000
Exit.TextWrapped = true

StopRape.Name = "StopRape"
StopRape.Parent = Frame
StopRape.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
StopRape.BorderColor3 = Color3.fromRGB(0, 0, 0)
StopRape.BorderSizePixel = 0
StopRape.Position = UDim2.new(0, 60, 0, 126)
StopRape.Size = UDim2.new(0, 156, 0, 25)
StopRape.Font = Enum.Font.SourceSansBold
StopRape.Text = "Stop Raping :("
StopRape.TextColor3 = Color3.fromRGB(255, 0, 0)
StopRape.TextSize = 14.000

TextLabel_2.Parent = Frame
TextLabel_2.BackgroundColor3 = Color3.fromRGB(30, 30, 20)
TextLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.BorderSizePixel = 0
TextLabel_2.Position = UDim2.new(0, 155, 0, 163)
TextLabel_2.Size = UDim2.new(0, 115, 0, 16)
TextLabel_2.Font = Enum.Font.SourceSansBold
TextLabel_2.Text = "By - Grandma96523"
TextLabel_2.TextColor3 = Color3.fromRGB(255, 0, 0)
TextLabel_2.TextSize = 14.000

-- Scripts:

local function GJIG_fake_script() -- Frame.LocalScript 
	local script = Instance.new('LocalScript', Frame)

	local playerNameTextBox = script.Parent:WaitForChild("PlayerTextBox")
	local playButton = script.Parent:WaitForChild("PlayButton")
	local stopRapeButton = script.Parent:WaitForChild("StopRape")
	local exitButton = script.Parent:WaitForChild("Exit")
	local gui = script.Parent
	local animationPlaying = nil
	local runServiceConnection = nil
	
	playButton.MouseButton1Click:Connect(function()
		local Victim = playerNameTextBox.Text
		local playerFound = nil
	
		-- Check for a player by their username or nickname
		for _, player in pairs(game:GetService("Players"):GetPlayers()) do
			if player.Name == Victim or player.DisplayName == Victim then
				playerFound = player
				break
			end
		end
	
		if playerFound then
			local A = Instance.new("Animation")
			A.AnimationId = 'rbxassetid://148840371'
			local P = game:GetService("Players").LocalPlayer
			local C = P.Character or P.CharacterAdded:Wait()
			local H = C:WaitForChild("Humanoid"):LoadAnimation(A)
			H:Play()
			H:AdjustSpeed(2.5)
	
			animationPlaying = H
	
			runServiceConnection = game:GetService("RunService").Stepped:Connect(function()
				if playerFound.Character then
					local victimRootPart = playerFound.Character:FindFirstChild("HumanoidRootPart")
					local localRootPart = C:WaitForChild("HumanoidRootPart")
	
					if victimRootPart then
						local offset = victimRootPart.CFrame.LookVector * -1
						localRootPart.CFrame = CFrame.new(victimRootPart.Position + offset, victimRootPart.Position)
					end
				end
			end)
		else
			print("No player found with the name or nickname " .. Victim)
		end
	end)
	
	stopRapeButton.MouseButton1Click:Connect(function()
		if animationPlaying then
			animationPlaying:Stop()
			print("Animation stopped.")
		end
		if runServiceConnection then
			runServiceConnection:Disconnect()
			print("Teleportation stopped.")
		end
	end)
	
	exitButton.MouseButton1Click:Connect(function()
		gui.Visible = false
		print("GUI closed. Press right Shift to reopen.")
	end)
	
	game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
		if input.KeyCode == Enum.KeyCode.RightShift and not gameProcessed then
			gui.Visible = not gui.Visible
		end
	end)
	
	local corner = Instance.new("UICorner")
	corner.CornerRadius = UDim.new(0, 12)
	corner.Parent = gui
	
	local dragging
	local dragStart
	local startPos
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 then
			dragging = true
			dragStart = input.Position
			startPos = gui.Position
	
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
			local delta = input.Position - dragStart
			gui.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
		end
	end)
end
coroutine.wrap(GJIG_fake_script)()